﻿namespace Asignment_PRN231_API_FE.ViewModel
{
    public class RecipeDetailsDto
    {
        public decimal Quantity { get; set; }
        public int IngredientId { get; set; }
    }
}

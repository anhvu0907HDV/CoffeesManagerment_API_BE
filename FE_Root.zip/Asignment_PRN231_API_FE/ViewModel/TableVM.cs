﻿namespace Asignment_PRN231_API_FE.ViewModel
{
    public class TableVM
    {
        public bool Status { get; set; }
        public int ShopId { get; set; }
        public string Name { get; set; } = null!;
    }
}

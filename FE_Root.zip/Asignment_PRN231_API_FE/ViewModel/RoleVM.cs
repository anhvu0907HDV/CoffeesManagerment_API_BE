﻿namespace Asignment_PRN231_API_FE.ViewModel
{
    public class RoleVM
    {
        public Guid RoleId { get; set; }
        public string RoleName { get; set; }
    }
}

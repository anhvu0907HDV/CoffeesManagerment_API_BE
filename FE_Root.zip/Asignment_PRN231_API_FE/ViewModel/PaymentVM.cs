﻿namespace Asignment_PRN231_API_FE.ViewModel
{
	public class PaymentVM
	{
		public string PaymentMethod { get; set; } = string.Empty;
		public string PaymentStatus { get; set; } = string.Empty;
	}
}

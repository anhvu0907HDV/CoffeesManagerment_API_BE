﻿namespace Asignment_PRN231_API_FE.ViewModel
{
	public class UserVM
	{
		public string FullName { get; set; } = string.Empty;
		public string Role { get; set; } = string.Empty;
	}
}

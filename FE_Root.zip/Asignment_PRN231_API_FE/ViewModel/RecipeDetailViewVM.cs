﻿namespace Asignment_PRN231_API_FE.ViewModel
{
    public class RecipeDetailViewVM
    {
        public decimal Quantity { get; set; }
        public string IngredientName { get; set; }
    }
}

﻿namespace Asignment_PRN231_API_FE.ViewModel
{
    public class IngredientDto
    {
        public int IngredientId { get; set; }
        public string? IngredientName { get; set; }
    }
}

﻿namespace Asignment_PRN231_API_FE.ViewModel
{
    public class CategoryVM
    {
        public int CategoryId { get; set; }
        public string? CategoryName { get; set; }
    }
}

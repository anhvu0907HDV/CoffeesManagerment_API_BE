using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Asignment_PRN231_API_FE.Pages.Authentication
{
    public class AccountModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

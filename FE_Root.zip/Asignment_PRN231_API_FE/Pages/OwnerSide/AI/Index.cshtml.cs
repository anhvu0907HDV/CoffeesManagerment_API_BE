using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Asignment_PRN231_API_FE.Pages.OwnerSide.AI
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
